#! /bin/bash

#rm -f *.html
#rm -f '.mhonarc.db'

imgrep +bfree/main3 --expression="to=b-free@iijnet.or.jp" |
while read i
do
  if [ $i -gt 1500 ]
  then
	  echo $i
	  fromMime ~/Mail/bfree/main3/$i | nkf -e| mhonarc -rcfile ./mhonarc.rc -treverse -reverse -add -title 'B-Free ML all'
  fi
done


