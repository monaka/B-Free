#!/bin/sh

rm -f *.html

pick +bfree -to b-free@iijnet.or.jp |
while read i
do
  echo $i
  fromMime ~/Mail/bfree/$i | nkf -e | hypermail -i -d . -l 'B-Free ML all' -u  -b '../index.html'
done

