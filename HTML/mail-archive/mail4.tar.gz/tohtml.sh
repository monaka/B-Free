#! /bin/bash

rm -f *.html
rm -f '.mhonarc.db'

imgrep +bfree/main4 --expression="to=bfree-prj@iijnet.or.jp" |
while read i
do
  echo $i
  nkf -m ~/Mail/bfree/main4/$i | nkf -e| mhonarc -rcfile ./mhonarc.rc -treverse -reverse -idxsize 20 -add -multipg -title 'B-Free ML all'
done

tar cvzf ../mail4.tar.gz .
